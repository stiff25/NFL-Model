# NFL Model V3.4 — pre-kickoff evidence collection (free-data approach)

This is a **data-collection and live-recording upgrade** to V3.3, **not a verified 68% Pick'em model** and not a 64% ATS system. It maintains market-first choices and your existing colour-coded dashboard.

## What to upload to GitHub

Replace **exactly these three files** in `stiff25/NFL-Model`:

1. Repository root: `nfl_model_v3.py` (keep this filename; it is V3.4 internally)
2. Repository root: `nfl_tracking_v34.py` (new)
3. `.github/workflows/update-model.yml` (replace existing workflow)

**Leave** `index.html`, `requirements.txt`, your existing `data` folder, and the repository secret `ODDS_API_KEY` untouched. Do not commit a secret or download one into the repository.

## Test

- In the GitHub website, open **Actions → Update NFL Model → Run workflow**, leave `run_backtest` unticked, run manually.
- The run should print `Odds API events received ...` and `V3.4 feed/archives: ...`.
- Confirm these files are created or updated on the `main` branch:
  - `data/current_picks.json` — same schema used by your dashboard.
  - `data/prediction_snapshots.jsonl` — timestamped prediction observations, append-only by snapshot ID.
  - `data/odds_snapshots.jsonl` — timestamped bookmaker moneylines/spreads when available.
  - `data/locked_picks.json` — latest verified-before-kickoff selection for each game (frozen after kickoff).
  - `data/pregame_deadline_odds_2026.csv` — importable, verified 2026 moneylines with capture/lock/kickoff timestamps.
  - `data/verified_pick_history.json` — same locked games plus official results when published.
  - `data/record.json` — standard dashboard results + direct pick-vs-favourite comparison.
- **Do not delete previous** `data/pick_history.json`; V3.4 deliberately doesn't treat legacy locks based on Melbourne calendar dates as verified pre-kickoff observations.
- After the manual run succeeds, automatic scheduled collection will continue. A `run_backtest` option is also available but unnecessary for the initial setup.

## Timing and availability

The workflow triggers a light preflight twice per hour (at :07 and :37 UTC), **but runs the expensive model and calls the Odds API only when a game is within 50 minutes of kickoff**. It also does one background live refresh daily. An optional manual trigger always runs the model. You can change this later if your observed API usage is too high.

- A confirmed sportsbook event's `commence_time` is preferred for kickoff; otherwise the nflverse `gameday` + `gametime` convention (US Eastern time) is used. Games without a known kickoff are never claimed as pre-kickoff captures.
- A prediction must be **generated before kickoff**. A quote must be **observed before kickoff**, and quoted moneylines must be a valid pair from the same named bookmaker.
- The closest available valid prediction before kickoff replaces earlier provisional locks. Once kickoff passes, late predictions **cannot rewrite** the pick. A capture made within 60 minutes is labelled `NEAR_KICKOFF`; earlier locks are labelled `EARLY_PREGAME`.
- GitHub's scheduled jobs are not real-time: **a final 10–15 minute lock cannot be guaranteed**. Delayed/missed runs create coverage gaps, not invented quotes.
- The existing API key worked in earlier V3.3 runs, but please check **your actual account's quota and market entitlements**. The 3 requested markets in one region can consume multiple credits per API request. We make no claim that Australian spread coverage is included on every free plan. If the account rejects a request, GitHub fails and the archive remains unchanged.
- This upgrade adds **no historical bookmaker prices from 2021–2025**, because no verified free complete archive was available. The old 5-year report remains a **model-only** backtest, while the new matched pre-kickoff comparison grows prospectively.

## How to read the results

`data/record.json` has `2026_live.market_first_comparison` with `games`, `model_wins`, `market_wins`, `net_correct_vs_favorites`, and both accuracies on the **same games**. A zero or absent number isn't proof of model quality. Don't judge the model by a couple of weeks of noise.

For each game the archive retains the last known actual pre-kickoff selection, price, and timestamp. The displayed strength system stays STRONG (orange), QUALIFIED (aqua), UPSET (purple), LEAN (yellow). No changes to the dashboard HTML are needed.

## Recover from a failed run

If **model ran but git push was rejected**, the workflow fetches the latest main branch and attempts a safe rebase before pushing. Never force-push. If it conflicts with an edit to the same data file, resolve the conflict or rerun the job after your edit; the workflow fails safely.

If **nothing new is collected**, look at `Decide whether to refresh`: preflight only does real work on the daily run, a manual request, or close to kickoff. Check the model's Odds API event count for missing bookmaker coverage, and remember nflverse results can lag.

### Files from this package

The included `data/` folder is intentionally blank. The first successful run creates the real files. No fabricated historical bookmaker odds or picks are included.
