"""Deterministic smoke/regression tests; no API or network used."""
from datetime import datetime, timezone, timedelta
from pathlib import Path
from tempfile import TemporaryDirectory
import pandas as pd

import nfl_tracking_v34 as t

BASE=datetime(2026,10,11,17,0,tzinfo=timezone.utc)
GAME={"game_id":"2026_06_PIT_TB","season":2026,"week":6,"game_type":"REG","gameday":"2026-10-11", "gametime":"13:00", "home_team":"TB", "away_team":"PIT", "home_score":None,"away_score":None}


def pick(offset=-30, quote_offset=-32, winner=0, home_ml=135, away_ml=-155):
    obs=BASE+timedelta(minutes=offset)
    quote=BASE+timedelta(minutes=quote_offset)
    return {
        "game_id":GAME["game_id"], "season":2026,"week":6,"gameday":"2026-10-11",
        "home_team":"TB","away_team":"PIT","kickoff_utc":"2026-10-11T17:00:00Z",
        "snapshot_utc":obs.isoformat(),"odds_observed_utc":quote.isoformat(),
        "home_ml":home_ml,"away_ml":away_ml,"ml_bookmaker":"sportsbook_test",
        "spread_home":2.5,"spread_bookmaker":"sportsbook_test",
        "pick_home":winner,"pickem_pick":"PIT" if winner==0 else "TB",
        "pickem_signal":"QUALIFIED","pickem_method":"MARKET_FIRST",
        "calibrated_model_home_prob":0.42,"confidence":0.58,
        "projected_margin":-2.8,"ats_action":"PASS ATS"}


def go():
    games=t.schedule_games([GAME])
    assert t.schedule_kickoff(GAME)==BASE
    assert abs(t.market_prob(135,-155)-((100/235)/((100/235)+(155/255))))<1e-9
    first=t.snapshot_from_pick(pick(),games, BASE-timedelta(minutes=29))
    assert first and first["market_quote_usable"] and first["market_favorite_pick_home"]==0
    assert first["lock_quality"]=="NEAR_KICKOFF"
    assert t.snapshot_from_pick(pick(offset=+1,quote_offset=-4),games,BASE+timedelta(minutes=2)) is None
    assert t.snapshot_from_pick(pick(offset=-1,quote_offset=+1),games,BASE) is not None
    assert t.snapshot_from_pick(pick(offset=-30,quote_offset=-32,home_ml=0),games,BASE)["market_favorite_pick_home"] is None
    assert t.snapshot_from_pick(pick(offset=-20),{},BASE) is not None # API kickoff verified
    missing=pick(offset=-20);missing["kickoff_utc"]=""
    assert t.snapshot_from_pick(missing,{},BASE) is None
    assert t.snapshot_from_pick(missing,games,BASE) is not None # schedule fallback
    with TemporaryDirectory() as tmp:
        root=Path(tmp)
        # Capture 30m before kickoff, then a newer one 5m before kickoff.
        output=t.update_model_archive(pd.DataFrame([pick()]),[GAME], BASE-timedelta(minutes=29),root)
        assert output["prediction_snapshots"]==1 and output["odds_snapshots"]==1
        assert len(t.read_jsonl(root/"odds_snapshots.jsonl"))==1
        rerun=t.update_model_archive(pd.DataFrame([pick()]),[GAME],BASE-timedelta(minutes=29),root)
        assert rerun["prediction_snapshots"]==0 # idempotent
        updated=t.update_model_archive(pd.DataFrame([pick(offset=-5,quote_offset=-7,winner=0)]),[GAME],BASE-timedelta(minutes=4),root)
        assert updated["prediction_snapshots"]==1
        assert len(t.read_jsonl(root/"odds_snapshots.jsonl"))==2
        late=t.update_model_archive(pd.DataFrame([pick(offset=+2,quote_offset=+1,winner=1)]),[GAME],BASE+timedelta(minutes=5),root)
        assert late["prediction_snapshots"]==0
        frozen=t.read_json(root/"locked_picks.json",[])
        assert len(frozen)==1 and frozen[0]["pick_home"]==0 and frozen[0]["prediction_observed_utc"]=="2026-10-11T16:55:00Z"
        done=dict(GAME,home_score=17,away_score=24)
        t.update_model_archive(pd.DataFrame([pick(offset=+2,quote_offset=+1,winner=1)]),[done],BASE+timedelta(hours=4),root)
        record=t.read_json(root/"record.json",{})
        comp=record["2026_live"]["market_first_comparison"]
        assert comp["games"]==1 and comp["market_wins"]==1 and comp["model_wins"]==1
        assert record["2026_live"]["pickem_all"]["wins"]==1
        # No post-kickoff price was recorded.
        assert len(t.read_jsonl(root/"odds_snapshots.jsonl"))==2
    sched=pd.DataFrame([GAME])
    yes,why=t.decide_preflight(sched,BASE-timedelta(minutes=24),False,False,[])
    assert yes and "pregame" in why
    no,why=t.decide_preflight(sched,BASE-timedelta(hours=2),False,False,[])
    assert not no
    daily,why=t.decide_preflight(sched,BASE-timedelta(days=1),False,True,[])
    assert daily
    just_ran=[{"game_id":GAME["game_id"],"prediction_observed_utc":t.iso(BASE-timedelta(minutes=30))}]
    no,why=t.decide_preflight(sched,BASE-timedelta(minutes=20),False,False,just_ran)
    assert not no # no repeat within 24 min
    print('All 15 V3.4 regression checks passed.')

if __name__=='__main__':go()
